export { default as extractBrandPage } from './extractBrandPage'
export { default as extractReviewPage } from './extractReviewPage'
export { default as extractSearchResultPage } from './extractSearchResultPage'
